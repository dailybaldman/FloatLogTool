package FloatLogTool;

public interface DataTube {
    
    void out(int tag,String data);
    
}
